import 'package:flutter/material.dart';

class LandingWrapper extends StatelessWidget {
  const LandingWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text('Landing Wrapper')),
    );
  }
}